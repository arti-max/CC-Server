#!/bin/sh
./CrossCraftServer
