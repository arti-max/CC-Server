start CrossCraftServer.exe
